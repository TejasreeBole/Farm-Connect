const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    cropType:{
        type:String,
        required:true,
        trim:true
    },
    cropName: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        min: 0
    },
    quantity: {
        type: String,
        required: true,
        trim: true
    },
    location: {
        type: String,
        required: true,
        trim: true
    },
    sellerName:{
        type:String,
        required:true,
        trim:true
    },
    sellerContact:{
        type:String,
        required:true,
        trim:true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const Product = mongoose.model("Product", productSchema);
module.exports = Product;
