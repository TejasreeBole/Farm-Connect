const express = require("express");
const path = require("path");
const hbs = require("hbs");
const session = require("express-session");
const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());



app.use(session({
    secret: "farmconnect_secret_key",
    resave: false,
    saveUninitialized: true
}));


const collection = require("./mongodb");
const Product = require("./product");

const templatePath = path.join(__dirname, "templates");
const publicPath = path.join(__dirname, "../public");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(publicPath));

app.set("view engine", "hbs");
app.set("views", templatePath);

// Entry Page
app.get("/", (req, res) => {
    console.log("Entry Page Loaded");
    res.render("entry");
});

// Signup Page
app.get("/signup", (req, res) => {
    res.render("signup");
});

// Login Page
app.get("/login", (req, res) => {
    res.render("login");
});

// Handle Signup
app.post("/signup", async (req, res) => {
    const { name, mobileNo, role } = req.body;

    if (!name || !mobileNo || !role) {
        return res.render("signup", { error: "Please enter all fields" });
    }

    const existingUser = await collection.findOne({ name: new RegExp('^' + name + '$', 'i') });
    if (existingUser) {
         return res.render("signup", { error: "User already exists" });
    }

    await collection.create({ name, mobileNo, role });
    if (role === 'supplier') {
        res.redirect("/all");
    } else {
        res.redirect("/buyer");
    }
});

// Handle Login
app.post("/login", async (req, res) => {
    try {
        const user = await collection.findOne({ name: new RegExp('^' + req.body.name + '$', 'i') });

        if (user && user.mobileNo === req.body.mobileNo) {
            req.session.user = {
                name: user.name,
                mobileNo: user.mobileNo,
                role: user.role
                
            };

            if (user.role === 'supplier') {
                res.redirect("/all");
            } else {
                res.redirect("/buyer");
            }
        } else {
            res.send("Invalid credentials");
        }
    } catch (error) {
        console.error(error);
        res.send("Error logging in");
    }
});


// Supplier Dashboard
app.get("/supplier", (req, res) => {
    res.render("supplier");
});
app.get("/all",(req,res)=>{
    res.render("all");
});
app.get("/home",(req,res)=>{
    res.render("home");
});
app.get("/grains",(req,res)=>{
    res.render("grains");
});
app.get("/wt_project", (req, res) => {
    res.render("wt_project");
});

// Buyer Dashboard
// Buyer Dashboard with product listings
app.get("/buyer", async (req, res) => {
    try {
        const products = await Product.find();
        res.render("buyer", { products });
    } catch (err) {
        console.error("Error fetching products:", err);
        res.send("Error loading products");
    }
});


// Sell Crop Form Page
app.get("/sell", (req, res) => {
    if (!req.session.user || req.session.user.role !== 'supplier') {
         return res.send("Unauthorized access to sell page");
    }
    res.render("sell");
});


// Handle Product Selling
app.post("/supplier", async (req, res) => {
    try {
        const { cropName, cropType, price, quantity, location } = req.body;

        if (!cropName || !cropType || !price || !quantity || !location) {
            return res.send("All product fields are required");
        }

        if (!req.session.user || req.session.user.role !== 'supplier') {
            return res.send("Unauthorized access");
        }

        await Product.create({
            cropName,
            cropType,
            price,
            quantity,
            location,
            sellerName: req.session.user.name,
            sellerContact: req.session.user.mobileNo
        });

        res.redirect("/supplier");
    } catch (err) {
        console.error("Error saving product:", err);
        res.status(500).send("Error saving product: " + err.message);
    }
});



app.post("/buy_info", (req, res) => {
    const { cropName, price, quantity, location,sellerName,sellerContact} = req.body;

    res.render("buy_info", {
        cropName,
        price,
        quantity,
        location,
        sellerName,
        sellerContact
    });
});


// Start Server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
